package InterakcjaKonsola;

public interface ZapisObiektu {
    Object saveObject();
}
